package week03.salma.id.ac.umn;

public class PreludeImmutability {
    public static void main(String[] args) {
        final String kode = "IF402";
        kode = "IF400";
    }
}
