package week07.salma.id.ac.umn;

public interface ClassInfo {

	public String getClassName();

}
