package latihan2;

public class BankC extends Bank {
    private int balance = 200;

    @Override
    public int getBalance() {
        return balance;
    }
}
