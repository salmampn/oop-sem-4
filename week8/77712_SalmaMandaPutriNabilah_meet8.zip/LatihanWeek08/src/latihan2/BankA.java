package latihan2;

public class BankA extends Bank {
    private int balance = 100;

    @Override
    public int getBalance() {
        return balance;
    }
}
