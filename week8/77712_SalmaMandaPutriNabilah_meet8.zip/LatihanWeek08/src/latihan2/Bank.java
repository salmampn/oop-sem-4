package latihan2;

public abstract class Bank {
    public abstract int getBalance();
}
