package latihan2;

public class BankB extends Bank {
    private int balance = 150;

    @Override
    public int getBalance() {
        return balance;
    }
}
