package latihan1;

public class Child2 extends Parent {
    public void message() {
        System.out.println("Ini adalah subkelas kedua");
    }
}
