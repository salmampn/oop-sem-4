package latihan1;

public abstract class Parent {
    public abstract void message();
}
