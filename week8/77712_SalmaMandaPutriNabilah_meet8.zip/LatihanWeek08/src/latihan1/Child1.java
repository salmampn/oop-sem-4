package latihan1;

public class Child1 extends Parent {
    public void message() {
        System.out.println("Ini adalah subkelas pertama");
    }
}
