package myPackage;

public class myClass {
    public void getNames(String s) {
        System.out.println(s);
    }
}
