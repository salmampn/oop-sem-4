package Tutorial;

public class CEO extends Pekerja {
    public CEO() {
    }

    public void tanyaIdentitas() {
        System.out.println("Saya seorang CEO");
    }

    public void tanyaPendapatan() {
        System.out.println("Pendapatan saya 100 juta per bulan");
    }
}
