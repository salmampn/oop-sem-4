package Tutorial;

public class Pekerja {
    public Pekerja() {
    }

    public void tanyaIdentitas() {
        System.out.println("Saya pekerja biasa");
    }
}
