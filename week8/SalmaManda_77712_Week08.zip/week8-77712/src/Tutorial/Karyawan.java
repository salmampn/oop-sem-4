package Tutorial;

public class Karyawan extends Pekerja {
    public Karyawan() {
    }

    public void tanyaIdentitas() {
        System.out.println("Saya seoarang Karyawan");
    }
}
