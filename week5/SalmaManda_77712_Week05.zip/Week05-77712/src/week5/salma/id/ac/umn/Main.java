package week5.salma.id.ac.umn;

public class Main {
    public static void main(String[] args) {
        Dog d = new Dog();
        d.bark();
        d.eat();
    }
}
