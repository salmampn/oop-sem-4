package week5.salma.id.ac.umn;

public class Dog extends Animal {

    public Dog() {
    }

    public void bark() {
        System.out.println("barking...");
    }
}
