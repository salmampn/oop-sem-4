package Tutorial;

public class Triangle {
    public Triangle() {
    }

    public void countSide() {
        System.out.println("Object ini memiliki 3 sisi");
    }
}
