package Tutorial;

public class Rectangle extends Polygon {
    public Rectangle() {
    }

    public void countSide() {
        System.out.println("Object ini memiliki 4 sisi");
    }
}
